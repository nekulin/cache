<?php
namespace providers;

class MemCache implements InterfaceProvider {

    public function set($strKey, $strValue) {}
    public function get($strKey) {}
} 