<?php
namespace providers;

class File implements InterfaceProvider {

    public function set($strKey, $strValue) {}
    public function get($strKey) {}
} 